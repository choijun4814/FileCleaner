# 파일정리 (FileCleaner)

안드로이드 파일정리 앱. Kotlin + Jetpack Compose, GitHub Actions로 APK 빌드.

## 빌드
1. 이 폴더 전체를 GitHub 저장소에 올립니다 (폴더 구조 그대로).
2. 저장소의 Actions 탭에서 "Build APK"가 끝나기를 기다립니다.
3. 실행 결과 아래 Artifacts의 FileCleaner-APK를 받아 압축을 풀고 app-debug.apk를 설치합니다.
