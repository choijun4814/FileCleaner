package app.filecleaner

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class AutoScanWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        val st = Settings(c)
        Ops.purgeOld(c, st)
        if (st.rootUri.isEmpty()) return Result.success()
        val sc = FileScanner.scan(c, Uri.parse(st.rootUri), st.excludedList().map { it.lowercase() }.toSet(), {}, { true })
        val (n, bytes) = Analyzer.quick(sc, st)
        if (n > 0) notify(c, n, bytes)
        return Result.success()
    }

    private fun notify(c: Context, n: Int, bytes: Long) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("auto", "정리 알림", NotificationManager.IMPORTANCE_DEFAULT))
        val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val nt = NotificationCompat.Builder(c, "auto")
            .setSmallIcon(android.R.drawable.ic_menu_delete)
            .setContentTitle("정리할 파일이 있어요")
            .setContentText("${n}개 · ${fmtSize(bytes)}")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(1, nt)
    }
}

object AutoScan {
    fun schedule(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<AutoScanWorker>(7, TimeUnit.DAYS).build()
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel(ctx: Context) { WorkManager.getInstance(ctx).cancelUniqueWork("auto") }
}
