package app.filecleaner

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Act { TRASH, MOVE, RENAME, RMDIR }

enum class Policy(val label: String) { SKIP("건너뛰기"), RENAME("번호 붙이기"), OVERWRITE("덮어쓰기") }

enum class Keep(val label: String) { OLDEST("오래된 것 남김"), NEWEST("최신 것 남김") }

enum class Rule(
    val title: String,
    val desc: String,
    val icon: ImageVector,
    val tint: Color,
    val organize: Boolean = false,
    val checked: Boolean = false
) {
    ZERO("0바이트 파일", "크기가 0인 빈 파일", Icons.Outlined.Description, Color(0xFF2E9E6B), false, true),
    EMPTY("빈 폴더", "안에 아무것도 없는 폴더", Icons.Outlined.Folder, Color(0xFF2E9E6B), false, true),
    PARTIAL("받다 만 파일", ".crdownload, .part 등", Icons.Outlined.Download, Color(0xFF1B9AAA), false, true),
    JUNK("정크·임시 파일", ".tmp, .log, .bak 등", Icons.Outlined.DeleteSweep, Color(0xFFD64545), false, true),
    DUP("중복 파일", "내용이 똑같은 파일", Icons.Outlined.ContentCopy, Color(0xFFE8892B), false, true),
    SIMILAR("비슷한 사진", "거의 같아 보이는 사진", Icons.Outlined.PhotoLibrary, Color(0xFF7B5CD6)),
    SHOT("오래된 스크린샷", "한동안 안 본 스크린샷", Icons.Outlined.Image, Color(0xFF3C7DE0)),
    APK("오래된 설치파일", "설치하고 남은 .apk", Icons.Outlined.Apps, Color(0xFF8A6D3B)),
    OLD("오래 안 쓴 파일", "오랫동안 수정 안 된 파일", Icons.Outlined.Schedule, Color(0xFF6B7280)),
    LARGE("큰 파일", "용량 큰 순서", Icons.Outlined.Storage, Color(0xFFC2410C)),
    BYTYPE("종류별 폴더로", "사진·영상·문서 등으로 나누기", Icons.Outlined.CreateNewFolder, Color(0xFF3C7DE0), true, true),
    BYDATE("연/월 폴더로", "수정일 기준 2026/11 형태", Icons.Outlined.CalendarMonth, Color(0xFF7B5CD6), true, true),
    CALL("통화녹음 모으기", "통화 녹음 파일을 한 폴더로", Icons.Outlined.Call, Color(0xFF2E9E6B), true, true),
    RENAME("날짜 이름 붙이기", "파일명 앞에 2026-11-27_ 붙이기", Icons.Outlined.Edit, Color(0xFF1B9AAA), true, true)
}

data class FileItem(
    val uri: String, val name: String, val size: Long, val modified: Long,
    val rel: String, val mime: String, val isDir: Boolean = false
) {
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
    val path: String get() = if (rel.isEmpty()) name else "$rel/$name"
}

data class DirInfo(val uri: String, val name: String, val rel: String, val empty: Boolean)
class ScanResult(val files: List<FileItem>, val dirs: List<DirInfo>)
data class Cand(val item: FileItem, val act: Act, val note: String = "", val dest: String = "", val newName: String = "")

data class LogEntry(
    val id: String, val batch: String, val time: Long, val type: String,
    val name: String, val newName: String, val srcRel: String, val dstRel: String,
    val uri: String, val root: String, val mime: String, val size: Long, val state: String
)

object Cat {
    private val map = linkedMapOf(
        "사진" to setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "bmp"),
        "영상" to setOf("mp4", "mkv", "avi", "mov", "3gp", "webm"),
        "음악" to setOf("mp3", "m4a", "flac", "wav", "ogg", "aac", "amr", "opus"),
        "문서" to setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "hwp", "hwpx", "csv", "md"),
        "압축" to setOf("zip", "rar", "7z", "tar", "gz"),
        "설치파일" to setOf("apk", "xapk")
    )
    fun of(ext: String): String = map.entries.firstOrNull { ext in it.value }?.key ?: "기타"
}

fun fmtSize(b: Long): String {
    if (b < 1024) return "${b}B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < 3) { v /= 1024; i++ }
    return String.format(Locale.US, if (v >= 100) "%.0f%s" else "%.1f%s", v, u[i])
}

fun fmtDate(ms: Long, pattern: String = "yyyy-MM-dd"): String =
    if (ms <= 0) "" else SimpleDateFormat(pattern, Locale.getDefault()).format(Date(ms))

fun actVerb(a: Act): String = when (a) {
    Act.TRASH -> "정리"
    Act.MOVE -> "이동"
    Act.RENAME -> "이름 바꾸기"
    Act.RMDIR -> "삭제"
}
