package app.filecleaner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Rect
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.face.FaceLandmark
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** n개 작업을 threads개 스레드로 나눠 처리 */
suspend fun parallelFor(n: Int, threads: Int, body: (Int) -> Unit) {
    if (n <= 0) return
    val idx = AtomicInteger(0)
    val pool = Executors.newFixedThreadPool(threads).asCoroutineDispatcher()
    try {
        coroutineScope {
            repeat(threads) {
                launch(pool) {
                    while (isActive) {
                        val i = idx.getAndIncrement()
                        if (i >= n) break
                        body(i)
                    }
                }
            }
        }
    } finally {
        pool.close()
    }
}

/** 촬영 날짜 판별: EXIF → 파일명 → 수정일 */
object Dates {
    val PHOTO = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
    val VIDEO = setOf("mp4", "mov", "3gp", "mkv", "avi", "webm")
    private val EXIF_EXT = setOf("jpg", "jpeg", "png", "webp", "heic", "heif")
    private val NAME_RE = Regex("(?<!\\d)((?:19|20)\\d{2})[-_.]?(0[1-9]|1[0-2])[-_.]?(0[1-9]|[12]\\d|3[01])(?!\\d)")

    class Meta(val orientation: Int, val taken: Long)

    private fun thisYear(): Int = Calendar.getInstance().get(Calendar.YEAR)

    fun valid(ms: Long): Boolean {
        if (ms <= 0) return false
        val y = Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.YEAR)
        return y in 1990..(thisYear() + 1)
    }

    fun fromName(name: String): Long {
        val m = NAME_RE.find(name) ?: return 0L
        return try {
            val y = m.groupValues[1].toInt()
            if (y > thisYear() + 1) return 0L
            Calendar.getInstance().apply {
                isLenient = false
                clear()
                set(y, m.groupValues[2].toInt() - 1, m.groupValues[3].toInt(), 12, 0, 0)
            }.timeInMillis
        } catch (e: Exception) {
            0L
        }
    }

    private fun parseExif(s: String?): Long {
        if (s == null) return 0L
        val t = s.trim()
        if (t.length < 19) return 0L
        return try {
            SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).apply { isLenient = false }
                .parse(t.substring(0, 19))?.time ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    fun meta(ctx: Context, uri: Uri): Meta {
        return try {
            ctx.contentResolver.openInputStream(uri)?.use { s ->
                val ex = ExifInterface(s)
                val o = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                val d = ex.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                    ?: ex.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED)
                    ?: ex.getAttribute(ExifInterface.TAG_DATETIME)
                Meta(o, parseExif(d))
            } ?: Meta(ExifInterface.ORIENTATION_NORMAL, 0L)
        } catch (e: Exception) {
            Meta(ExifInterface.ORIENTATION_NORMAL, 0L)
        }
    }

    fun pick(exif: Long, name: String, modified: Long): Long {
        if (valid(exif)) return exif
        val n = fromName(name)
        if (n > 0) return n
        return if (modified > 0) modified else 0L
    }

    fun resolve(ctx: Context, f: FileItem): Long {
        val ex = if (f.ext in EXIF_EXT) meta(ctx, Uri.parse(f.uri)).taken else 0L
        return pick(ex, f.name, f.modified)
    }

    /** 폴더 경로: style 0 = 2024/03, style 1 = 2024년/03월 */
    fun rel(ms: Long, style: Int): String {
        if (ms <= 0) return "날짜미상"
        val c = Calendar.getInstance().apply { timeInMillis = ms }
        val y = c.get(Calendar.YEAR)
        val m = c.get(Calendar.MONTH) + 1
        val mm = if (m < 10) "0$m" else "$m"
        return if (style == 0) "$y/$mm" else "${y}년/${mm}월"
    }

    fun safeName(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().trim('.').ifEmpty { "이름없음" }
}

class Det(
    val l: Float, val t: Float, val r: Float, val b: Float,
    val q: Float, val emb: FloatArray, val thumb: ByteArray
)

class Analysis(val taken: Long, val faces: List<Det>)

/** 얼굴 검출(ML Kit) + 정렬 + 임베딩(TFLite) */
object FaceEngine {
    val IMG = setOf("jpg", "jpeg", "png", "webp", "heic", "heif")
    private const val MODEL_TFLITE = "face_model.tflite"
    private const val MODEL_ONNX = "face_model.onnx"

    private var detector: FaceDetector? = null
    private var interp: Interpreter? = null
    private var ortEnv: OrtEnvironment? = null
    private var ortSession: OrtSession? = null
    private var onnxInputName: String = ""
    private var onnxNchw: Boolean = true

    var inSize = 112
        private set
    var outDim = 192
        private set
    var sig = ""
        private set
    var error = ""
        private set

    fun modelFile(ctx: Context): File = File(ctx.filesDir, MODEL_ONNX)
    fun legacyModelFile(ctx: Context): File = File(ctx.filesDir, MODEL_TFLITE)

    private fun assetExists(ctx: Context): Boolean =
        try { ctx.assets.open(MODEL_TFLITE).close(); true } catch (e: Exception) { false }

    fun hasModel(ctx: Context): Boolean =
        modelFile(ctx).exists() || legacyModelFile(ctx).exists() || assetExists(ctx)

    @Synchronized
    fun reset() {
        try { interp?.close() } catch (e: Exception) {}
        try { ortSession?.close() } catch (e: Exception) {}
        try { detector?.close() } catch (e: Exception) {}
        interp = null
        ortSession = null
        ortEnv = null
        onnxInputName = ""
        detector = null
    }

    @Synchronized
    fun init(ctx: Context): Boolean {
        if ((interp != null || ortSession != null) && detector != null) return true
        error = ""
        try {
            val onnxFile = modelFile(ctx)
            val tfliteFile = legacyModelFile(ctx)
            if (onnxFile.exists()) {
                // ONNX Runtime opens the file by path; avoid loading the 174 MB model into a second byte array.
                val env = OrtEnvironment.getEnvironment()
                val session = OrtSession.SessionOptions().use { options ->
                    options.setIntraOpNumThreads(2)
                    options.setInterOpNumThreads(1)
                    options.setExecutionMode(OrtSession.SessionOptions.ExecutionMode.SEQUENTIAL)
                    options.setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
                    env.createSession(onnxFile.absolutePath, options)
                }
                ortEnv = env
                ortSession = session
                val inputName = session.inputNames.firstOrNull()
                    ?: throw IllegalArgumentException("ONNX 입력이 없습니다.")
                val inputInfo = session.inputInfo[inputName]?.info as? TensorInfo
                    ?: throw IllegalArgumentException("ONNX 입력 텐서 정보를 읽을 수 없습니다.")
                val shape = inputInfo.shape
                if (shape.size != 4) throw IllegalArgumentException("4차원 얼굴 입력 모델이 아닙니다: ${shape.contentToString()}")
                val nchw = shape[1] == 3L || shape[1] == -1L
                val h = if (nchw) shape[2] else shape[1]
                val w = if (nchw) shape[3] else shape[2]
                if (h <= 0L || w <= 0L || h != w || h > 512L) {
                    throw IllegalArgumentException("지원하지 않는 ONNX 입력 크기입니다: ${shape.contentToString()}")
                }
                inSize = h.toInt()
                val outputName = session.outputNames.firstOrNull()
                    ?: throw IllegalArgumentException("ONNX 출력이 없습니다.")
                val outputInfo = session.outputInfo[outputName]?.info as? TensorInfo
                    ?: throw IllegalArgumentException("ONNX 출력 텐서 정보를 읽을 수 없습니다.")
                val outShape = outputInfo.shape
                outDim = outShape.lastOrNull()?.toInt() ?: 0
                if (outDim !in 128..4096) throw IllegalArgumentException("지원하지 않는 얼굴 특징 출력 크기: $outDim")
                ortEnv = env
                ortSession = session
                onnxInputName = inputName
                onnxNchw = nchw
                sig = "onnx_fast_singlepass_v2_${onnxFile.length()}_${inSize}_$outDim"
            } else {
                val bytes = if (tfliteFile.exists()) tfliteFile.readBytes()
                    else ctx.assets.open(MODEL_TFLITE).use { it.readBytes() }
                val buf = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
                buf.put(bytes)
                buf.rewind()
                val opt = Interpreter.Options().apply { setNumThreads(2) }
                val ip = Interpreter(buf, opt)
                val ins = ip.getInputTensor(0)
                val outs = ip.getOutputTensor(0)
                val ish = ins.shape()
                if (ins.dataType() != DataType.FLOAT32 || outs.dataType() != DataType.FLOAT32) {
                    ip.close()
                    error = "FLOAT32 TFLite 모델만 지원해요."
                    return false
                }
                if (ish.size != 4 || ish[3] != 3 || ish[1] != ish[2]) {
                    ip.close()
                    error = "지원하지 않는 TFLite 입력 형태예요."
                    return false
                }
                inSize = ish[1]
                outDim = outs.numElements()
                sig = "tflite_${bytes.size}_${inSize}_$outDim"
                interp = ip
            }
            detector = FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                    .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                    .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
                    .setMinFaceSize(0.03f)
                    .build()
            )
            return true
        } catch (e: Throwable) {
            reset()
            error = "모델을 열 수 없어요: ${e.message}"
            return false
        }
    }

    // ---------- 이미지 읽기 ----------

    private fun decode(ctx: Context, uri: Uri): Bitmap? {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        val mx = max(o.outWidth, o.outHeight)
        var s = 1
        while (mx / (s * 2) >= 1280) s *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = s }
        var bm = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return null
        val m2 = max(bm.width, bm.height)
        if (m2 > 2000) {
            val f = 1600f / m2
            bm = Bitmap.createScaledBitmap(bm, max(1, (bm.width * f).toInt()), max(1, (bm.height * f).toInt()), true)
        }
        return bm
    }

    private fun orient(bm: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> { m.postRotate(180f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(-90f)
            else -> return bm
        }
        return Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, m, true)
    }

    // ---------- 얼굴 정렬 ----------

    /** 두 눈을 수평·표준 위치로 맞춘 inSize x inSize 얼굴 이미지 */
    private fun alignEyes(bm: Bitmap, p1: PointF, p2: PointF): Bitmap? {
        val a = if (p1.x <= p2.x) p1 else p2
        val b = if (p1.x <= p2.x) p2 else p1
        val dx = b.x - a.x
        val dy = b.y - a.y
        val dist = hypot(dx, dy)
        if (dist < 4f) return null
        val s = inSize.toFloat()
        val scale = 0.3146f * s / dist
        val angle = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
        val pre = if (scale < 0.5f) scale * 2f else 1f
        val src = if (pre < 1f)
            Bitmap.createScaledBitmap(bm, max(1, (bm.width * pre).toInt()), max(1, (bm.height * pre).toInt()), true)
        else bm
        val mx = (a.x + b.x) / 2f * pre
        val my = (a.y + b.y) / 2f * pre
        val sc = scale / pre
        val m = Matrix()
        m.postTranslate(-mx, -my)
        m.postRotate(-angle)
        m.postScale(sc, sc)
        m.postTranslate(s / 2f, 0.4607f * s)
        val out = Bitmap.createBitmap(inSize, inSize, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** 눈 위치를 못 얻었을 때: 박스 기준으로 자르기 */
    private fun cropBox(bm: Bitmap, bb: Rect): Bitmap {
        val side = max(bb.width(), bb.height()) * 1.25f
        val cx = bb.exactCenterX()
        val cy = bb.exactCenterY()
        val l = max(0, (cx - side / 2f).toInt())
        val t = max(0, (cy - side / 2f).toInt())
        val r = min(bm.width, (cx + side / 2f).toInt())
        val b = min(bm.height, (cy + side / 2f).toInt())
        val out = Bitmap.createBitmap(inSize, inSize, Bitmap.Config.ARGB_8888)
        if (r - l < 2 || b - t < 2) return out
        Canvas(out).drawBitmap(bm, Rect(l, t, r, b), Rect(0, 0, inSize, inSize), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    // ---------- 임베딩 ----------

    private fun l2(v: FloatArray): FloatArray {
        var s = 0f
        for (x in v) s += x * x
        val n = sqrt(s)
        if (n > 1e-6f) for (i in v.indices) v[i] /= n
        return v
    }

    private fun embedOne(bm: Bitmap): FloatArray? {
        val s = inSize
        val px = IntArray(s * s)
        bm.getPixels(px, 0, s, 0, 0, s, s)
        val session = ortSession
        if (session != null) {
            // InsightFace w600k_r50 expects NCHW BGR input normalized to [-1, 1].
            val input = FloatArray(3 * s * s)
            val plane = s * s
            for (i in px.indices) {
                val p = px[i]
                val r = ((p shr 16) and 0xFF).toFloat()
                val g = ((p shr 8) and 0xFF).toFloat()
                val b = (p and 0xFF).toFloat()
                if (onnxNchw) {
                    input[i] = (b - 127.5f) / 127.5f
                    input[plane + i] = (g - 127.5f) / 127.5f
                    input[2 * plane + i] = (r - 127.5f) / 127.5f
                } else {
                    input[i * 3] = (b - 127.5f) / 127.5f
                    input[i * 3 + 1] = (g - 127.5f) / 127.5f
                    input[i * 3 + 2] = (r - 127.5f) / 127.5f
                }
            }
            val shape = if (onnxNchw) longArrayOf(1, 3, s.toLong(), s.toLong())
                else longArrayOf(1, s.toLong(), s.toLong(), 3)
            val env = ortEnv ?: return null
            OnnxTensor.createTensor(env, java.nio.FloatBuffer.wrap(input), shape).use { tensor ->
                session.run(mapOf(onnxInputName to tensor)).use { result ->
                    val value = result[0].value
                    val out = when (value) {
                        is FloatArray -> value
                        is Array<*> -> {
                            val first = value.firstOrNull()
                            when (first) {
                                is FloatArray -> first
                                is Array<*> -> (first.firstOrNull() as? FloatArray) ?: return null
                                else -> return null
                            }
                        }
                        else -> return null
                    }
                    if (out.size != outDim) return null
                    return out.copyOf()
                }
            }
        }

        val ip = interp ?: return null
        val v = FloatArray(s * s * 3)
        for (i in px.indices) {
            val p = px[i]
            v[i * 3] = ((p shr 16) and 0xFF).toFloat()
            v[i * 3 + 1] = ((p shr 8) and 0xFF).toFloat()
            v[i * 3 + 2] = (p and 0xFF).toFloat()
        }
        if (s >= 160) {
            var mean = 0f
            for (x in v) mean += x
            mean /= v.size
            var vs = 0f
            for (x in v) vs += (x - mean) * (x - mean)
            val std = max(sqrt(vs / v.size), 1f / sqrt(v.size.toFloat()))
            for (i in v.indices) v[i] = (v[i] - mean) / std
        } else {
            for (i in v.indices) v[i] = (v[i] - 127.5f) / 128f
        }
        val inBuf = ByteBuffer.allocateDirect(v.size * 4).order(ByteOrder.nativeOrder())
        inBuf.asFloatBuffer().put(v)
        val outBuf = ByteBuffer.allocateDirect(outDim * 4).order(ByteOrder.nativeOrder())
        synchronized(ip) { ip.run(inBuf, outBuf) }
        outBuf.rewind()
        val r = FloatArray(outDim)
        outBuf.asFloatBuffer().get(r)
        return r
    }

    /** 속도 최적화: 정렬된 얼굴은 1회만 추론하고 특징 벡터를 정규화한다.
     * 좌우 반전 추가 추론(TTA)은 사진 수가 많을 때 처리 시간을 거의 두 배로 늘리므로 생략한다.
     */
    private fun embed(aligned: Bitmap): FloatArray? {
        val bm = if (aligned.width == inSize && aligned.height == inSize) aligned
        else Bitmap.createScaledBitmap(aligned, inSize, inSize, true)
        val result = embedOne(bm) ?: return null
        return l2(result)
    }

    // ---------- 사진 한 장 분석 ----------

    fun analyze(ctx: Context, uri: Uri, name: String, modified: Long): Analysis? {
        val det = detector ?: return null
        val meta = Dates.meta(ctx, uri)
        val taken = Dates.pick(meta.taken, name, modified)
        val raw = decode(ctx, uri) ?: return Analysis(taken, emptyList())
        val bm = orient(raw, meta.orientation)
        val found = try {
            Tasks.await(det.process(InputImage.fromBitmap(bm, 0)))
        } catch (e: Exception) {
            emptyList()
        }
        val out = ArrayList<Det>()
        for (face in found) {
            val bb = face.boundingBox
            val w = bb.width()
            val h = bb.height()
            if (min(w, h) < 48) continue
            val yaw = face.headEulerAngleY
            if (abs(yaw) > 45f) continue
            val le = face.getLandmark(FaceLandmark.LEFT_EYE)?.position
            val re = face.getLandmark(FaceLandmark.RIGHT_EYE)?.position
            val aligned = (if (le != null && re != null) alignEyes(bm, le, re) else null) ?: cropBox(bm, bb)
            val emb = embed(aligned) ?: continue
            val q = min(w, h) * (1f - abs(yaw) / 90f)
            val bos = ByteArrayOutputStream()
            aligned.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            out.add(
                Det(
                    bb.left.toFloat() / bm.width, bb.top.toFloat() / bm.height,
                    bb.right.toFloat() / bm.width, bb.bottom.toFloat() / bm.height,
                    q, emb, bos.toByteArray()
                )
            )
        }
        return Analysis(taken, out)
    }
}
