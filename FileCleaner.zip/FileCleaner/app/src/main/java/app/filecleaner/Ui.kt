@file:OptIn(ExperimentalMaterial3Api::class)

package app.filecleaner

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.DocumentsContract
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.DeleteForever
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

@Composable
fun FileCleanerTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = if (Build.VERSION.SDK_INT >= 31) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else if (dark) darkColorScheme(primary = Color(0xFF9DB8FF)) else lightColorScheme(primary = Color(0xFF2F6FED))
    MaterialTheme(colorScheme = cs, content = content)
}

private fun storage(): Pair<Long, Long> {
    val s = StatFs(Environment.getExternalStorageDirectory().path)
    return s.totalBytes to s.availableBytes
}

fun rootLabel(uri: String): String = runCatching {
    DocumentsContract.getTreeDocumentId(Uri.parse(uri)).substringAfter(':').ifEmpty { "내부 저장소 전체" }
}.getOrDefault(uri)

@Composable
fun App(vm: AppVM) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            vm.setRoot(uri.toString())
        }
    }
    val destPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            vm.setDest(uri.toString())
        }
    }
    val busyNow = vm.running || vm.bg || vm.scanning
    DisposableEffect(busyNow) {
        val w = (ctx as? Activity)?.window
        if (busyNow) w?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose { w?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }
    val cur = vm.current
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when {
            vm.scanning -> ScanningScreen(vm)
            vm.viewPerson != null -> PersonScreen(vm) { destPicker.launch(null) }
            cur != null -> PreviewScreen(vm, cur)
            else -> Scaffold(bottomBar = {
                NavigationBar {
                    listOf("홈" to Icons.Outlined.Home, "정리" to Icons.Outlined.AutoAwesome, "사람" to Icons.Outlined.Face, "기록" to Icons.Outlined.History, "설정" to Icons.Outlined.Settings)
                        .forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(selected = vm.tab == i, onClick = { vm.tab = i }, icon = { Icon(icon, null) }, label = { Text(label) })
                        }
                }
            }) { pad ->
                Box(Modifier.padding(pad)) {
                    when (vm.tab) {
                        0 -> HomeScreen(vm) { picker.launch(null) }
                        1 -> OrganizeScreen(vm)
                        2 -> PeopleScreen(vm) { destPicker.launch(null) }
                        3 -> HistoryScreen(vm)
                        else -> SettingsScreen(vm) { picker.launch(null) }
                    }
                }
            }
        }
    }
    vm.message?.let { m ->
        AlertDialog(
            onDismissRequest = { vm.message = null },
            confirmButton = { TextButton(onClick = { vm.message = null }) { Text("확인") } },
            text = { Text(m) }
        )
    }
    if (vm.running) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = { TextButton(onClick = { vm.cancel() }) { Text("취소") } },
            title = { Text("처리 중") },
            text = {
                Column {
                    LinearProgressIndicator(progress = { if (vm.total == 0) 0f else vm.done.toFloat() / vm.total }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("${vm.done} / ${vm.total}")
                }
            }
        )
    }
    if (vm.bg) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = { TextButton(onClick = { vm.cancel() }) { Text("취소") } },
            title = { Text(vm.bgStage) },
            text = {
                Column {
                    if (vm.bgTotal > 0) {
                        LinearProgressIndicator(progress = { (vm.bgDone.toFloat() / vm.bgTotal).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Text("${vm.bgDone} / ${vm.bgTotal}")
                    } else {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        if (vm.bgDone > 0) {
                            Spacer(Modifier.height(8.dp))
                            Text("${vm.bgDone}개")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("취소해도 지금까지 분석한 내용은 저장돼요. 화면을 켜 둔 채로 기다려 주세요.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }
    vm.plan?.let { p ->
        AlertDialog(
            onDismissRequest = { vm.plan = null },
            title = { Text("${p.cands.size}개를 ${if (p.move) "이동" else "복사"}할까요?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("저장 위치: ${p.destLabel}")
                    Spacer(Modifier.height(4.dp))
                    p.lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        if (p.move) "이동하면 원래 위치에서 사라져요. 기록 탭에서 되돌릴 수 있어요."
                        else "원본은 그대로 두고 복사해요. 기록 탭에서 되돌릴 수 있어요.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = { TextButton(onClick = { vm.plan = null; vm.execute(p.cands, true) }) { Text("실행") } },
            dismissButton = { TextButton(onClick = { vm.plan = null }) { Text("취소") } }
        )
    }
}

@Composable
fun ScanningScreen(vm: AppVM) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        CircularProgressIndicator()
        Spacer(Modifier.height(20.dp))
        Text(vm.stage, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text("${vm.found}개 파일 읽음", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        OutlinedButton(onClick = { vm.cancel() }) { Text("취소") }
    }
}

@Composable
fun RuleCard(rule: Rule, list: List<Cand>, mod: Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = mod, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp)) {
            Box(Modifier.size(40.dp).background(rule.tint.copy(alpha = 0.15f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(rule.icon, null, tint = rule.tint)
            }
            Spacer(Modifier.height(10.dp))
            Text(rule.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            Text("${list.size}개 · ${fmtSize(list.sumOf { it.item.size })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun HomeScreen(vm: AppVM, pick: () -> Unit) {
    val (total, free) = remember { storage() }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("파일정리", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp)) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("정리할 수 있는 용량", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(if (vm.scanned) fmtSize(vm.reclaimable()) else "-", style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { ((total - free).toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    Text("저장공간 ${fmtSize(total)} 중 ${fmtSize(total - free)} 사용", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        item {
            OutlinedCard(onClick = pick, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Folder, null)
                    Spacer(Modifier.size(12.dp))
                    Text(if (vm.rootUri.isEmpty()) "정리할 폴더 선택" else rootLabel(vm.rootUri), modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("변경", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        item { Button(onClick = { vm.startScan() }, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("스캔 시작") } }
        if (vm.scanned) {
            items(Rule.entries.filter { !it.organize }.chunked(2)) { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { r -> RuleCard(r, vm.results[r].orEmpty(), Modifier.weight(1f)) { vm.current = r } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
fun OrganizeScreen(vm: AppVM) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("정리", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp))
            Text("선택한 폴더 바로 아래에 있는 파일만 정리해요. 하위 폴더 안의 파일은 건드리지 않아요.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
        }
        if (!vm.scanned) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("먼저 스캔이 필요해요.")
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { vm.startScan() }) { Text("스캔 시작") }
                    }
                }
            }
        } else {
            items(Rule.entries.filter { it.organize }) { r ->
                val l = vm.results[r].orEmpty()
                Card(onClick = { vm.current = r }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).background(r.tint.copy(alpha = 0.15f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(r.icon, null, tint = r.tint)
                        }
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.title, fontWeight = FontWeight.Medium)
                            Text(r.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text("${l.size}개")
                    }
                }
            }
        }
    }
}

@Composable
fun PreviewScreen(vm: AppVM, rule: Rule) {
    val list = vm.results[rule].orEmpty()
    val checked = remember(rule, list) { mutableStateMapOf<String, Boolean>().also { m -> list.forEach { m[it.item.uri] = rule.checked } } }
    val sel = list.filter { checked[it.item.uri] == true }
    var confirm by remember { mutableStateOf(false) }
    val act = list.firstOrNull()?.act ?: Act.TRASH
    BackHandler { vm.close() }
    val guide = when (act) {
        Act.TRASH -> if (vm.st.useTrash) "선택한 파일은 앱 휴지통으로 가요. ${vm.st.trashDays}일 동안 복구할 수 있어요." else "휴지통을 끄면 바로 삭제돼요. 되돌릴 수 없어요."
        Act.MOVE -> "선택한 파일을 폴더로 옮겨요. 이름이 겹치면 '${vm.st.policy.label}'(으)로 처리해요."
        Act.COPY -> "선택한 파일을 폴더로 복사해요. 원본은 그대로예요."
        Act.RENAME -> "이름 앞에 수정 날짜를 붙여요. 기록에서 되돌릴 수 있어요."
        Act.RMDIR -> "비어 있는 폴더만 삭제해요. 되돌릴 수 없어요."
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.close() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "뒤로") }
            Text(rule.title, style = MaterialTheme.typography.titleLarge)
        }
        Text(guide, modifier = Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (list.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("찾은 항목이 없어요.") }
        } else {
            Row(Modifier.fillMaxWidth().clickable {
                val all = sel.size != list.size
                list.forEach { checked[it.item.uri] = all }
            }.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = sel.size == list.size, onCheckedChange = { all -> list.forEach { checked[it.item.uri] = all } })
                Text("전체 선택 · ${sel.size}/${list.size} · ${fmtSize(sel.sumOf { it.item.size })}")
            }
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.item.uri }) { c ->
                    val on = checked[c.item.uri] == true
                    Row(Modifier.fillMaxWidth().clickable { checked[c.item.uri] = !on }.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = on, onCheckedChange = { checked[c.item.uri] = it })
                        if (c.item.ext in Analyzer.IMG) {
                            AsyncImage(model = c.item.uri, contentDescription = null, modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                        } else {
                            Box(Modifier.size(44.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                Icon(if (c.item.isDir) Icons.Outlined.Folder else Icons.Outlined.Description, null)
                            }
                        }
                        Spacer(Modifier.size(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(listOf(c.item.rel.ifEmpty { "/" }, fmtSize(c.item.size), fmtDate(c.item.modified)).filter { it.isNotEmpty() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (c.note.isNotEmpty()) Text(c.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            Button(onClick = { confirm = true }, enabled = sel.isNotEmpty(), modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp)) {
                Text("선택한 ${sel.size}개 ${actVerb(act)}하기")
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("${sel.size}개를 ${actVerb(act)}할까요?") },
            text = { Text(guide + if (sel.size > vm.st.maxBatch) "\n한 번에 ${vm.st.maxBatch}개까지만 처리해요." else "") },
            confirmButton = { TextButton(onClick = { confirm = false; vm.execute(sel) }) { Text("실행") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("취소") } }
        )
    }
}

@Composable
fun HistoryScreen(vm: AppVM) {
    var sub by remember { mutableIntStateOf(0) }
    var confirmPurge by remember { mutableStateOf<List<LogEntry>?>(null) }
    val typeName = mapOf("TRASH" to "휴지통", "MOVE" to "이동", "COPY" to "복사", "RENAME" to "이름변경", "RMDIR" to "빈폴더삭제", "DELETE" to "삭제")
    Column(Modifier.fillMaxSize()) {
        Text("기록", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp))
        TabRow(selectedTabIndex = sub) {
            Tab(selected = sub == 0, onClick = { sub = 0 }, text = { Text("작업 기록") })
            Tab(selected = sub == 1, onClick = { sub = 1 }, text = { Text("휴지통") })
        }
        if (sub == 0) {
            val batches = vm.logs.groupBy { it.batch }.values.sortedByDescending { it.first().time }
            if (batches.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("아직 기록이 없어요.") }
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Spacer(Modifier.height(4.dp)) }
                items(batches, key = { it.first().batch }) { b ->
                    val undoable = b.filter { it.state == "ACTIVE" }
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text(fmtDate(b.first().time, "MM-dd HH:mm"), fontWeight = FontWeight.Medium)
                            Text(b.groupBy { it.type }.map { "${typeName[it.key] ?: it.key} ${it.value.size}개" }.joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            if (undoable.isNotEmpty()) OutlinedButton(onClick = { vm.undo(undoable) }) { Text("전체 되돌리기 (${undoable.size}개)") }
                            else Text("되돌릴 항목 없음", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        } else {
            val trash = vm.logs.filter { it.type == "TRASH" && it.state == "ACTIVE" }.sortedByDescending { it.time }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${trash.size}개 · ${fmtSize(trash.sumOf { it.size })}", modifier = Modifier.weight(1f))
                TextButton(onClick = { if (trash.isNotEmpty()) confirmPurge = trash }) { Text("비우기") }
            }
            if (trash.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("휴지통이 비어 있어요.") }
            LazyColumn(Modifier.fillMaxSize()) {
                items(trash, key = { it.id }) { e ->
                    val left = (vm.st.trashDays - (System.currentTimeMillis() - e.time) / 86_400_000L).coerceAtLeast(0)
                    ListItem(
                        headlineContent = { Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text("${fmtSize(e.size)} · ${left}일 남음") },
                        trailingContent = {
                            Row {
                                IconButton(onClick = { vm.undo(listOf(e)) }) { Icon(Icons.Outlined.Restore, "복구") }
                                IconButton(onClick = { confirmPurge = listOf(e) }) { Icon(Icons.Outlined.DeleteForever, "영구 삭제") }
                            }
                        }
                    )
                }
            }
        }
    }
    confirmPurge?.let { l ->
        AlertDialog(
            onDismissRequest = { confirmPurge = null },
            title = { Text("${l.size}개를 영구 삭제할까요?") },
            text = { Text("되돌릴 수 없어요.") },
            confirmButton = { TextButton(onClick = { vm.purge(l); confirmPurge = null }) { Text("삭제") } },
            dismissButton = { TextButton(onClick = { confirmPurge = null }) { Text("취소") } }
        )
    }
}

@Composable
private fun Section(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 14.dp))
}

@Composable
private fun NumField(label: String, value: Int, onChange: (Int) -> Unit) {
    var text by remember { mutableStateOf(value.toString()) }
    OutlinedTextField(
        value = text,
        onValueChange = { t -> text = t.filter { it.isDigit() }.take(6); text.toIntOrNull()?.let(onChange) },
        label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
fun ChipRow(opts: List<String>, sel: Int, onSel: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        opts.forEachIndexed { i, o -> FilterChip(selected = sel == i, onClick = { onSel(i) }, label = { Text(o) }) }
    }
}

@Composable
fun SettingsScreen(vm: AppVM, pick: () -> Unit) {
    val st = vm.st
    val ctx = LocalContext.current
    var excl by remember { mutableStateOf(st.excludedList()) }
    var newEx by remember { mutableStateOf("") }
    var junk by remember { mutableStateOf(st.junk) }
    var policy by remember { mutableIntStateOf(st.policy.ordinal) }
    var keep by remember { mutableIntStateOf(st.keep.ordinal) }
    var auto by remember { mutableStateOf(st.auto) }
    var useTrash by remember { mutableStateOf(st.useTrash) }
    var confirmReset by remember { mutableStateOf(false) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("설정", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 16.dp)) }
        item {
            Section("정리할 폴더")
            OutlinedButton(onClick = pick, modifier = Modifier.fillMaxWidth()) { Text(if (vm.rootUri.isEmpty()) "폴더 선택" else rootLabel(vm.rootUri), maxLines = 1, overflow = TextOverflow.Ellipsis) }
        }
        item {
            Section("제외 폴더 (스캔에서 뺍니다)")
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = newEx, onValueChange = { newEx = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("폴더 이름 또는 경로") })
                IconButton(onClick = {
                    val t = newEx.trim()
                    if (t.isNotEmpty()) { excl = (excl + t).distinct(); st.excluded = excl.joinToString("\n"); newEx = "" }
                }) { Icon(Icons.Outlined.Add, "추가") }
            }
        }
        items(excl) { e ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Folder, null)
                Spacer(Modifier.size(8.dp))
                Text(e, modifier = Modifier.weight(1f))
                IconButton(onClick = { excl = excl - e; st.excluded = excl.joinToString("\n") }) { Icon(Icons.Outlined.Close, "삭제") }
            }
        }
        item {
            Section("정크 파일 확장자 (쉼표로 구분)")
            OutlinedTextField(value = junk, onValueChange = { junk = it; st.junk = it }, modifier = Modifier.fillMaxWidth())
        }
        item {
            Section("기준값")
            NumField("오래된 파일 기준 (일)", st.oldDays) { st.oldDays = it }
        }
        item { NumField("오래된 스크린샷 기준 (일)", st.shotDays) { st.shotDays = it } }
        item { NumField("큰 파일 기준 (MB)", st.largeMb) { st.largeMb = it } }
        item { NumField("한 번에 처리할 최대 개수", st.maxBatch) { st.maxBatch = it.coerceAtLeast(1) } }
        item {
            Section("이름이 겹칠 때")
            ChipRow(Policy.entries.map { it.label }, policy) { policy = it; st.policyName = Policy.entries[it].name }
        }
        item {
            Section("중복 파일은")
            ChipRow(Keep.entries.map { it.label }, keep) { keep = it; st.keepName = Keep.entries[it].name }
        }
        item {
            Section("휴지통")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("휴지통 사용 (끄면 바로 삭제)", modifier = Modifier.weight(1f))
                Switch(checked = useTrash, onCheckedChange = { useTrash = it; st.useTrash = it })
            }
        }
        item { NumField("휴지통 보관 기간 (일)", st.trashDays) { st.trashDays = it.coerceAtLeast(1) } }
        item {
            Section("얼굴 인식")
            NumField("묶는 엄격도 (30~90, 높을수록 엄격)", st.faceSim) { st.faceSim = it.coerceIn(30, 90) }
        }
        item { NumField("목록에 보일 최소 사진 수", st.minPhotos) { st.minPhotos = it.coerceAtLeast(1); vm.refreshPeople() } }
        item { OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("얼굴 데이터 모두 지우기") } }
        item {
            Section("자동 점검")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("주 1회 점검하고 알려주기", modifier = Modifier.weight(1f))
                Switch(checked = auto, onCheckedChange = { on ->
                    auto = on
                    st.auto = on
                    if (on) {
                        if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
                        AutoScan.schedule(ctx)
                    } else AutoScan.cancel(ctx)
                })
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("얼굴 데이터를 지울까요?") },
            text = { Text("붙여둔 이름과 사람 묶음이 모두 사라져요. 사진 파일은 그대로예요.") },
            confirmButton = { TextButton(onClick = { confirmReset = false; vm.resetFaces() }) { Text("지우기") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("취소") } }
        )
    }
}
