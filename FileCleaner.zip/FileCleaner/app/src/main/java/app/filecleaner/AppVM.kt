package app.filecleaner

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class AppVM(private val app: Application) : AndroidViewModel(app) {
    val st = Settings(app)
    var tab by mutableIntStateOf(0)
    var current by mutableStateOf<Rule?>(null)
    var rootUri by mutableStateOf(st.rootUri)
    var scanning by mutableStateOf(false)
    var stage by mutableStateOf("")
    var found by mutableIntStateOf(0)
    var scanned by mutableStateOf(false)
    var results by mutableStateOf<Map<Rule, List<Cand>>>(emptyMap())
    var running by mutableStateOf(false)
    var done by mutableIntStateOf(0)
    var total by mutableIntStateOf(0)
    var message by mutableStateOf<String?>(null)
    var logs by mutableStateOf(st.logs())
    private var job: Job? = null

    init {
        viewModelScope.launch(Dispatchers.IO) {
            Ops.purgeOld(app, st)
            logs = st.logs()
        }
    }

    fun setRoot(u: String) {
        st.rootUri = u
        rootUri = u
        scanned = false
        results = emptyMap()
    }

    fun reclaimable(): Long = results.filterKeys { it.checked && !it.organize }.values.flatten()
        .filter { it.act != Act.RMDIR }.distinctBy { it.item.uri }.sumOf { it.item.size }

    fun close() { current = null }

    fun cancel() { job?.cancel() }

    fun startScan() {
        if (scanning || running) return
        if (st.rootUri.isEmpty()) { message = "먼저 정리할 폴더를 선택하세요."; return }
        scanning = true
        found = 0
        stage = "폴더 읽는 중"
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                val excluded = st.excludedList().map { it.lowercase() }.toSet()
                val sc = FileScanner.scan(app, Uri.parse(st.rootUri), excluded, { found = it }, { isActive })
                val res = Analyzer.analyze(app, sc, st, { stage = it }, { isActive })
                if (isActive) { results = res; scanned = true }
            } catch (e: Exception) {
                message = "스캔 실패: ${e.message}"
            } finally {
                scanning = false
            }
        }
    }

    fun execute(cands: List<Cand>) {
        if (running) return
        val root = Ops.root(app, st)
        if (root == null) { message = "폴더 접근 권한을 확인하세요."; return }
        val rootStr = st.rootUri
        val list = cands.take(st.maxBatch)
        running = true
        done = 0
        total = list.size
        job = viewModelScope.launch(Dispatchers.IO) {
            val batch = UUID.randomUUID().toString()
            val newLogs = ArrayList<LogEntry>()
            val finished = HashSet<String>()
            var fail = 0
            var skip = 0
            try {
                for (c in list) {
                    if (!isActive) break
                    try {
                        val e = Ops.run(app, st, root, rootStr, c, batch)
                        if (e != null) { newLogs.add(e); finished.add(c.item.uri) } else skip++
                    } catch (ex: Exception) {
                        fail++
                    }
                    done++
                }
            } finally {
                st.appendLogs(newLogs)
                results = results.mapValues { (_, v) -> v.filter { it.item.uri !in finished } }
                logs = st.logs()
                running = false
                var msg = "완료: ${newLogs.size}개 처리"
                if (skip > 0) msg += ", 건너뜀 $skip개"
                if (fail > 0) msg += ", 실패 $fail개"
                if (cands.size > list.size) msg += "\n한 번에 처리하는 최대 개수(${st.maxBatch}개)만 처리했어요. 한 번 더 실행하세요."
                message = msg
            }
        }
    }

    fun undo(entries: List<LogEntry>) {
        if (running) return
        running = true
        done = 0
        total = entries.size
        job = viewModelScope.launch(Dispatchers.IO) {
            var ok = 0
            val all = st.logs().toMutableList()
            try {
                for (e in entries) {
                    if (!isActive) break
                    if (Ops.undo(app, e)) {
                        ok++
                        val i = all.indexOfFirst { it.id == e.id }
                        if (i >= 0) all[i] = all[i].copy(state = "UNDONE")
                    }
                    done++
                }
            } finally {
                st.saveLogs(all)
                logs = all
                scanned = false
                results = emptyMap()
                running = false
                message = "되돌림: $ok/${entries.size}개\n목록이 바뀌었으니 다시 스캔하세요."
            }
        }
    }

    fun purge(entries: List<LogEntry>) {
        viewModelScope.launch(Dispatchers.IO) {
            val ids = entries.map { it.id }.toSet()
            entries.forEach { Ops.purge(app, it) }
            val all = st.logs().map { if (it.id in ids) it.copy(state = "PURGED") else it }
            st.saveLogs(all)
            logs = all
        }
    }
}
